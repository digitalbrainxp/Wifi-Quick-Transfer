import jsQR from "jsqr";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { parsePairPayload } from "@/lib/share/ids";
import { cn } from "@/lib/utils";

type Detector = {
  detect: (source: ImageBitmapSource) => Promise<Array<{ rawValue: string }>>;
};

export function Scanner({
  onRoom,
}: {
  onRoom: (roomId: string) => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [manual, setManual] = useState("");
  const [manualError, setManualError] = useState<string | null>(null);
  const found = useRef(false);

  useEffect(() => {
    let stream: MediaStream | null = null;
    let raf = 0;
    let cancelled = false;

    async function start() {
      if (!navigator.mediaDevices?.getUserMedia) {
        setCameraError("Camera is not available in this browser.");
        return;
      }
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          audio: false,
          video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 } },
        });
      } catch {
        setCameraError("Camera permission is needed to scan, or type the code below.");
        return;
      }
      if (cancelled) {
        stream.getTracks().forEach((t) => t.stop());
        return;
      }
      const video = videoRef.current;
      if (!video) return;
      video.srcObject = stream;
      await video.play().catch(() => {});

      const DetectorCtor = (window as unknown as { BarcodeDetector?: new (opts: { formats: string[] }) => Detector })
        .BarcodeDetector;
      let detector: Detector | null = null;
      if (DetectorCtor) {
        try {
          detector = new DetectorCtor({ formats: ["qr_code"] });
        } catch {
          detector = null;
        }
      }

      const tick = async () => {
        if (cancelled || found.current) return;
        const canvas = canvasRef.current;
        if (video.readyState >= 2 && canvas) {
          const w = video.videoWidth;
          const h = video.videoHeight;
          if (w && h) {
            canvas.width = w;
            canvas.height = h;
            const ctx = canvas.getContext("2d", { willReadFrequently: true });
            if (ctx) {
              ctx.drawImage(video, 0, 0);
              let raw: string | null = null;
              if (detector) {
                try {
                  const codes = await detector.detect(canvas);
                  raw = codes[0]?.rawValue ?? null;
                } catch {
                  raw = null;
                }
              }
              if (!raw) {
                const image = ctx.getImageData(0, 0, w, h);
                const code = jsQR(image.data, w, h, { inversionAttempts: "dontInvert" });
                raw = code?.data ?? null;
              }
              if (raw) {
                const room = parsePairPayload(raw);
                if (room && !found.current) {
                  found.current = true;
                  onRoom(room);
                  return;
                }
              }
            }
          }
        }
        raf = window.requestAnimationFrame(() => void tick());
      };
      raf = window.requestAnimationFrame(() => void tick());
    }

    void start();
    return () => {
      cancelled = true;
      window.cancelAnimationFrame(raf);
      stream?.getTracks().forEach((t) => t.stop());
    };
  }, [onRoom]);

  function submitManual(event: FormEvent) {
    event.preventDefault();
    const room = parsePairPayload(manual);
    if (!room) {
      setManualError("That code doesn’t look right. Check the eight characters under the QR.");
      return;
    }
    setManualError(null);
    onRoom(room);
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="relative overflow-hidden rounded-xl bg-ink">
        <video
          ref={videoRef}
          className={cn("aspect-[3/4] w-full object-cover", cameraError && "hidden")}
          playsInline
          muted
          autoPlay
        />
        <canvas ref={canvasRef} className="hidden" />
        {!cameraError ? (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-ink/40">
            <div className="size-[62%] rounded-lg border-2 border-surface-2" />
          </div>
        ) : (
          <div className="flex aspect-[3/4] items-center justify-center px-8 text-center">
            <p className="text-sm leading-relaxed text-ink-fg/80">{cameraError}</p>
          </div>
        )}
      </div>

      <form onSubmit={submitManual} className="flex flex-col gap-2">
        <label htmlFor="pair-code" className="text-xs font-medium uppercase tracking-[0.16em] text-muted">
          Or type the pairing code
        </label>
        <div className="flex gap-2">
          <input
            id="pair-code"
            value={manual}
            onChange={(e) => {
              setManual(e.target.value.toUpperCase());
              setManualError(null);
            }}
            inputMode="text"
            autoCapitalize="characters"
            autoCorrect="off"
            spellCheck={false}
            placeholder="K7M2 P9Q4"
            className={cn(
              "h-11 flex-1 rounded-md border border-border bg-surface px-3",
              "font-mono text-sm tracking-[0.2em] text-fg placeholder:text-subtle",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40",
            )}
          />
          <Button type="submit" variant="ink" size="md">
            Join
          </Button>
        </div>
        {manualError ? <p className="text-xs text-danger">{manualError}</p> : null}
      </form>
    </div>
  );
}
