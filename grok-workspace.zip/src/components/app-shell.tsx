import type { ReactNode } from "react";
import { AppMark } from "@/components/app-mark";
import { ThemeToggle } from "@/components/theme-toggle";
import { cn } from "@/lib/utils";

export function AppShell({
  children,
  footer,
}: {
  children: ReactNode;
  footer?: ReactNode;
}) {
  return (
    <div className="relative min-h-dvh bg-bg text-fg">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 h-64 bg-[radial-gradient(120%_80%_at_50%_-10%,color-mix(in_oklab,var(--accent)_18%,transparent),transparent_70%)]"
      />
      <div className="relative mx-auto flex min-h-dvh w-full max-w-[430px] flex-col px-5 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-[max(0.75rem,env(safe-area-inset-top))]">
        <header className="flex items-center justify-between py-2">
          <div className="flex items-center gap-2.5">
            <AppMark className="size-9" />
            <div>
              <p className="text-sm font-semibold tracking-tight">WiFi Share</p>
              <p className="text-xs text-muted">Direct device transfer</p>
            </div>
          </div>
          <ThemeToggle />
        </header>
        <main className="flex flex-1 flex-col">{children}</main>
        {footer ? <footer className="pt-6 text-center text-xs text-subtle">{footer}</footer> : null}
      </div>
    </div>
  );
}

export function ScreenHeader({
  title,
  subtitle,
  onBack,
}: {
  title: string;
  subtitle?: string;
  onBack?: () => void;
}) {
  return (
    <div className="flex items-start gap-3 pt-4">
      {onBack ? (
        <button
          type="button"
          onClick={onBack}
          className={cn(
            "mt-0.5 flex size-11 shrink-0 items-center justify-center rounded-md",
            "border border-border bg-surface text-fg",
            "transition-transform duration-150 ease-out active:scale-[0.96]",
          )}
          aria-label="Back"
        >
          <svg viewBox="0 0 24 24" className="size-5" fill="none" aria-hidden="true">
            <path
              d="M15 6 9 12l6 6"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
      ) : null}
      <div className="min-w-0 pt-1">
        <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
        {subtitle ? <p className="mt-1 text-sm text-muted">{subtitle}</p> : null}
      </div>
    </div>
  );
}
