import { useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useRef } from "react";
import { AppShell, ScreenHeader } from "@/components/app-shell";
import { ErrorCard, SuccessCard } from "@/components/outcome";
import { ProgressPanel } from "@/components/progress-panel";
import { Scanner } from "@/components/scanner";
import { Button } from "@/components/ui/button";
import { beginReceive, cancelActive, stopAndReset } from "@/lib/share/controller";
import { useShareStore } from "@/lib/share/store";

export function ReceiveView({ initialRoom }: { initialRoom?: string }) {
  const navigate = useNavigate();
  const state = useShareStore();
  const started = useRef<string | null>(null);

  const goHome = useCallback(async () => {
    await stopAndReset();
    void navigate({ to: "/" });
  }, [navigate]);

  const join = useCallback(async (room: string) => {
    started.current = room;
    await beginReceive(room);
  }, []);

  useEffect(() => {
    if (initialRoom && started.current !== initialRoom && state.phase === "idle") {
      void join(initialRoom);
    }
  }, [initialRoom, join, state.phase]);

  const phase = state.phase;
  const scanning = phase === "idle";

  return (
    <AppShell>
      <ScreenHeader
        title={
          phase === "complete"
            ? "Received"
            : phase === "failed"
              ? "Receive failed"
              : phase === "transferring" || phase === "connecting"
                ? "Receiving"
                : "Receive"
        }
        subtitle={scanning ? "Point the camera at the sender’s QR code." : undefined}
        onBack={
          phase === "complete"
            ? undefined
            : () => {
                void cancelActive("Cancelled");
                void goHome();
              }
        }
      />

      {scanning ? (
        <div className="stagger-in mt-5 flex flex-1 flex-col">
          <Scanner onRoom={(room) => void join(room)} />
        </div>
      ) : null}

      {phase === "connecting" || phase === "transferring" ? (
        <div className="mt-6 flex flex-1 flex-col gap-5">
          <ProgressPanel
            phase={phase}
            files={state.files}
            transferredBytes={state.transferredBytes}
            totalBytes={state.totalBytes}
            speedBps={state.speedBps}
            etaSec={state.etaSec}
            peerConnected={state.peerConnected}
            linkType={state.linkType}
            rttMs={state.rttMs}
            statusText={state.statusText}
          />
          <Button variant="danger" size="md" block onClick={() => void cancelActive("Transfer cancelled")}>
            Cancel
          </Button>
        </div>
      ) : null}

      {phase === "complete" ? (
        <SuccessCard
          title="Saved on this device"
          body="Files arrived over the direct link. Tap any file if a download didn’t start."
          files={state.files}
          received={state.received}
          onHome={() => void goHome()}
        />
      ) : null}

      {phase === "failed" ? (
        <ErrorCard
          message={state.error ?? "Could not connect to the sender."}
          onRetry={() => {
            void (async () => {
              await stopAndReset();
              if (initialRoom) await join(initialRoom);
            })();
          }}
          onHome={() => void goHome()}
        />
      ) : null}
    </AppShell>
  );
}
