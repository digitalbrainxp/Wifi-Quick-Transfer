import QRCode from "qrcode";

export async function makeQrDataUrl(text: string): Promise<string> {
  return QRCode.toDataURL(text, {
    errorCorrectionLevel: "M",
    margin: 1,
    width: 480,
    color: { dark: "#171614", light: "#ffffff" },
  });
}

export function pairUrl(room: string): string {
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  const url = new URL("/receive", origin || "https://wifishare.local");
  url.searchParams.set("room", room);
  return url.toString();
}
