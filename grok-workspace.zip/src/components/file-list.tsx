import { File as FileIcon, Film, Image as ImageIcon, Music } from "lucide-react";
import { fileKind, formatBytes } from "@/lib/share/format";
import type { FileProgress } from "@/lib/share/store";
import { cn } from "@/lib/utils";

function KindIcon({ name, mime }: { name: string; mime: string }) {
  const kind = fileKind(name, mime);
  const Icon = kind === "image" ? ImageIcon : kind === "video" ? Film : kind === "audio" ? Music : FileIcon;
  return <Icon className="size-4" strokeWidth={1.75} />;
}

export function FileList({
  files,
  showProgress = false,
}: {
  files: FileProgress[];
  showProgress?: boolean;
}) {
  return (
    <ul className="flex flex-col gap-2">
      {files.map((file) => {
        const pct = file.size > 0 ? Math.min(100, (file.bytes / file.size) * 100) : file.status === "done" ? 100 : 0;
        return (
          <li
            key={file.id}
            className="rounded-lg border border-border bg-surface px-3.5 py-3"
          >
            <div className="flex items-center gap-3">
              <span className="flex size-9 shrink-0 items-center justify-center rounded-sm bg-fg/5 text-fg">
                <KindIcon name={file.name} mime={file.mime} />
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{file.name}</p>
                <p className="text-xs text-muted tabular-nums">
                  {showProgress ? `${formatBytes(file.bytes)} / ${formatBytes(file.size)}` : formatBytes(file.size)}
                </p>
              </div>
              {file.status === "done" ? (
                <span className="text-xs font-medium text-success">Done</span>
              ) : file.status === "active" ? (
                <span className="text-xs font-medium text-muted tabular-nums">{Math.round(pct)}%</span>
              ) : null}
            </div>
            {showProgress ? (
              <div className="mt-2 h-1 overflow-hidden rounded-full bg-fg/8">
                <div
                  className={cn(
                    "h-full rounded-full bg-accent transition-[width] duration-200 ease-out",
                    file.status === "done" && "bg-success",
                  )}
                  style={{ width: `${pct}%` }}
                />
              </div>
            ) : null}
          </li>
        );
      })}
    </ul>
  );
}
