import { createFileRoute } from "@tanstack/react-router";
import { ReceiveView } from "@/components/receive-view";

export const Route = createFileRoute("/receive")({
  validateSearch: (search: Record<string, unknown>) => ({
    room: typeof search.room === "string" && search.room.length > 0 ? search.room : undefined,
  }),
  component: ReceivePage,
});

function ReceivePage() {
  const { room } = Route.useSearch();
  return <ReceiveView initialRoom={room} />;
}
