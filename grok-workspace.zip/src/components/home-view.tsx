import { ArrowDownToLine, ArrowUpFromLine } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";

export function HomeView() {
  return (
    <AppShell footer="Files travel directly between devices. Nothing is uploaded.">
      <div className="stagger-in flex flex-1 flex-col justify-center gap-5 py-8">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted">Nearby</p>
          <h1 className="mt-2 text-[2.15rem] leading-[1.1] font-semibold tracking-tight">
            Send a file
            <span className="block text-muted">without the cloud.</span>
          </h1>
          <p className="mt-3 max-w-[34ch] text-sm leading-relaxed text-muted">
            Pair with a QR code, then transfer over a direct Wi-Fi link. No Bluetooth. No internet required once connected.
          </p>
        </div>

        <Link
          to="/send"
          className="group flex min-h-36 flex-col justify-between rounded-2xl bg-ink px-6 py-6 text-ink-fg transition-transform duration-150 ease-out active:scale-[0.98]"
        >
          <span className="flex size-12 items-center justify-center rounded-lg bg-ink-fg/10">
            <ArrowUpFromLine className="size-6" strokeWidth={1.75} />
          </span>
          <span>
            <span className="block text-2xl font-semibold tracking-tight">Send</span>
            <span className="mt-1 block text-sm text-ink-fg/70">Choose files and show a QR code</span>
          </span>
        </Link>

        <Link
          to="/receive"
          search={{}}
          className="group flex min-h-36 flex-col justify-between rounded-2xl bg-accent px-6 py-6 text-accent-fg transition-transform duration-150 ease-out active:scale-[0.98]"
        >
          <span className="flex size-12 items-center justify-center rounded-lg bg-accent-fg/10">
            <ArrowDownToLine className="size-6" strokeWidth={1.75} />
          </span>
          <span>
            <span className="block text-2xl font-semibold tracking-tight">Receive</span>
            <span className="mt-1 block text-sm text-accent-fg/70">Scan the sender’s QR code</span>
          </span>
        </Link>
      </div>
    </AppShell>
  );
}
