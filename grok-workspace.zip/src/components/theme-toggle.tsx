import { Moon, Sun } from "lucide-react";
import { useEffect, useState } from "react";
import { applyTheme, persistTheme, readTheme, type Theme } from "@/lib/share/theme";
import { cn } from "@/lib/utils";

export function ThemeToggle() {
  const [theme, setTheme] = useState<Theme>("system");

  useEffect(() => {
    setTheme(readTheme());
  }, []);

  function cycle() {
    const next: Theme = theme === "light" ? "dark" : "light";
    setTheme(next);
    persistTheme(next);
    applyTheme(next);
  }

  const dark =
    theme === "dark" ||
    (theme === "system" &&
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-color-scheme: dark)").matches);

  return (
    <button
      type="button"
      onClick={cycle}
      aria-label={dark ? "Switch to light mode" : "Switch to dark mode"}
      className={cn(
        "relative size-11 rounded-md text-fg",
        "transition-transform duration-150 ease-out active:scale-[0.96]",
        "hover:bg-fg/5",
      )}
    >
      <span className="relative mx-auto block size-5">
        <Sun
          className={cn(
            "absolute inset-0 size-5 transition-[opacity,transform,filter] duration-250",
            dark ? "scale-100 opacity-100 blur-0" : "scale-[0.25] opacity-0 blur-[4px]",
          )}
          strokeWidth={1.75}
        />
        <Moon
          className={cn(
            "absolute inset-0 size-5 transition-[opacity,transform,filter] duration-250",
            dark ? "scale-[0.25] opacity-0 blur-[4px]" : "scale-100 opacity-100 blur-0",
          )}
          strokeWidth={1.75}
        />
      </span>
    </button>
  );
}
