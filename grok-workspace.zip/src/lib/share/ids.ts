const ALPHABET = "abcdefghijkmnpqrstuvwxyz23456789";

function randomChars(length: number): string {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  let out = "";
  for (const b of bytes) out += ALPHABET[b % ALPHABET.length];
  return out;
}

/** Room id accepted by the signaling relay: `[a-zA-Z0-9_-]{1,64}`. */
export function createRoomId(): string {
  return `wfs_${randomChars(8)}`;
}

export function createPeerId(role: "s" | "r"): string {
  return `${role}_${randomChars(12)}`;
}

export function displayCode(roomId: string): string {
  const raw = roomId.startsWith("wfs_") ? roomId.slice(4) : roomId;
  return raw.replace(/(.{4})/g, "$1 ").trim().toUpperCase();
}

export type PairPayload = {
  v: 1;
  app: "wifishare";
  room: string;
};

export function encodePairPayload(room: string): string {
  const payload: PairPayload = { v: 1, app: "wifishare", room };
  return JSON.stringify(payload);
}

export function parsePairPayload(raw: string): string | null {
  const text = raw.trim();
  if (!text) return null;

  try {
    const url = new URL(text);
    const room = url.searchParams.get("room") ?? url.searchParams.get("code");
    if (room && /^[a-zA-Z0-9_-]{1,64}$/.test(room)) return room;
  } catch {
    // not a URL
  }

  if (text.startsWith("WFS1:")) {
    const room = text.slice(5).trim();
    if (/^[a-zA-Z0-9_-]{1,64}$/.test(room)) return room;
  }

  try {
    const json = JSON.parse(text) as { room?: unknown; r?: unknown; app?: unknown };
    const room = typeof json.room === "string" ? json.room : typeof json.r === "string" ? json.r : null;
    if (room && /^[a-zA-Z0-9_-]{1,64}$/.test(room)) return room;
  } catch {
    // not JSON
  }

  const compact = text.replace(/\s+/g, "").toLowerCase();
  if (/^[a-z0-9]{8}$/.test(compact)) return `wfs_${compact}`;
  if (/^wfs_[a-zA-Z0-9_-]{1,60}$/.test(compact)) return compact;
  if (/^[a-zA-Z0-9_-]{1,64}$/.test(compact) && compact.startsWith("wfs_")) return compact;
  return null;
}
