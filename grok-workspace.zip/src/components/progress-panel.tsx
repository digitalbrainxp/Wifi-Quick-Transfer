import { Check, Wifi, WifiOff } from "lucide-react";
import { FileList } from "@/components/file-list";
import { formatBytes, formatEta, formatSpeed } from "@/lib/share/format";
import type { FileProgress, SharePhase } from "@/lib/share/store";
import { cn } from "@/lib/utils";

function linkLabel(type: string | null, connected: boolean) {
  if (!connected) return "Connecting";
  if (type === "host") return "Local Wi-Fi link";
  if (type === "srflx" || type === "prflx") return "Direct peer link";
  if (type === "relay") return "Relayed link";
  return "Direct link";
}

export function ProgressPanel({
  phase,
  files,
  transferredBytes,
  totalBytes,
  speedBps,
  etaSec,
  peerConnected,
  linkType,
  rttMs,
  statusText,
}: {
  phase: SharePhase;
  files: FileProgress[];
  transferredBytes: number;
  totalBytes: number;
  speedBps: number;
  etaSec: number | null;
  peerConnected: boolean;
  linkType: string | null;
  rttMs: number | null;
  statusText: string;
}) {
  const pct = totalBytes > 0 ? Math.min(100, (transferredBytes / totalBytes) * 100) : phase === "complete" ? 100 : 0;
  const done = phase === "complete";

  return (
    <div className="flex flex-col gap-5">
      <div className="rounded-xl border border-border bg-surface p-5">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-sm">
            {peerConnected ? (
              <Wifi className="size-4 text-success" strokeWidth={1.75} />
            ) : (
              <WifiOff className="size-4 text-muted" strokeWidth={1.75} />
            )}
            <span className={peerConnected ? "text-success" : "text-muted"}>
              {linkLabel(linkType, peerConnected)}
            </span>
          </div>
          {rttMs !== null && peerConnected ? (
            <span className="text-xs text-subtle tabular-nums">{rttMs} ms</span>
          ) : null}
        </div>

        <div className="mt-5 flex items-end justify-between">
          <p className="text-4xl font-semibold tracking-tight tabular-nums">
            {done ? "100" : Math.round(pct)}
            <span className="ml-1 text-lg font-medium text-muted">%</span>
          </p>
          {done ? (
            <span className="mb-1 flex items-center gap-1.5 text-sm font-medium text-success">
              <Check className="size-4" strokeWidth={2} />
              Complete
            </span>
          ) : (
            <p className={cn("mb-1 text-sm text-muted", phase === "connecting" && "shimmer-text")}>{statusText}</p>
          )}
        </div>

        <div className="mt-4 h-2 overflow-hidden rounded-full bg-fg/8">
          <div
            className={cn(
              "h-full rounded-full transition-[width] duration-200 ease-out",
              done ? "bg-success" : "bg-accent",
            )}
            style={{ width: `${pct}%` }}
          />
        </div>

        <div className="mt-3 flex justify-between text-xs text-muted tabular-nums">
          <span>
            {formatBytes(transferredBytes)} / {formatBytes(totalBytes)}
          </span>
          <span>
            {done ? "Finished" : `${formatSpeed(speedBps)} · ${formatEta(etaSec)}`}
          </span>
        </div>
      </div>

      {files.length > 0 ? <FileList files={files} showProgress /> : null}
    </div>
  );
}
