import { P2PRoom, type PeerInfo } from "@/lib/multiplayer";
import { createPeerId, createRoomId } from "./ids";
import {
  patchShare,
  resetShareState,
  useShareStore,
  type FileProgress,
  type ReceivedFile,
} from "./store";

const CHUNK = 16 * 1024;
const WAIT_PEER_MS = 3 * 60 * 1000;

type ControlMessage =
  | { t: "manifest"; files: { id: string; name: string; size: number; mime: string }[] }
  | { t: "accept" }
  | { t: "done" }
  | { t: "cancel" }
  | { t: "error"; m: string };

type LiveSession = {
  p2p: P2PRoom;
  role: "send" | "receive";
  closed: boolean;
  peerId: string | null;
  files: File[];
  metas: FileProgress[];
  accept: { resolve: () => void; promise: Promise<void> } | null;
  incoming: IncomingState | null;
  samples: { t: number; b: number }[];
};

type IncomingState = {
  list: FileProgress[];
  index: number;
  receivedInFile: number;
  parts: ArrayBuffer[];
  finished: boolean;
};

let live: LiveSession | null = null;

function isControl(value: unknown): value is ControlMessage {
  if (!value || typeof value !== "object" || !("t" in value)) return false;
  const t = (value as { t: unknown }).t;
  return t === "manifest" || t === "accept" || t === "done" || t === "cancel" || t === "error";
}

function fail(message: string) {
  patchShare({ phase: "failed", error: message, statusText: "Transfer failed" });
}

function noteSpeed(transferred: number) {
  if (!live) return;
  const now = performance.now();
  live.samples.push({ t: now, b: transferred });
  while (live.samples.length > 1 && now - live.samples[0]!.t > 1500) live.samples.shift();
  let speedBps = 0;
  if (live.samples.length >= 2) {
    const first = live.samples[0]!;
    const last = live.samples[live.samples.length - 1]!;
    const dt = (last.t - first.t) / 1000;
    if (dt > 0) speedBps = (last.b - first.b) / dt;
  }
  const total = useShareStore.getState().totalBytes;
  const remaining = Math.max(0, total - transferred);
  const etaSec = speedBps > 0 ? remaining / speedBps : null;
  patchShare({ transferredBytes: transferred, speedBps, etaSec });
}

function applyPeer(peers: PeerInfo[]) {
  const connected = peers.find((p) => p.connectionState === "connected") ?? peers[0];
  if (!connected) {
    patchShare({ peerConnected: false, linkType: null, rttMs: null });
    return;
  }
  patchShare({
    peerConnected: connected.connectionState === "connected",
    linkType: connected.candidateType,
    rttMs: connected.rttMs,
  });
  if (live && !live.closed && live.peerId && connected.connectionState === "failed") {
    fail("The direct link dropped. Stay close and try again.");
    void teardown();
  }
}

function onMessage(from: string, data: unknown) {
  if (!live || live.closed || !isControl(data)) return;
  if (data.t === "cancel") {
    fail("The other device cancelled the transfer.");
    void teardown();
    return;
  }
  if (data.t === "error") {
    fail(data.m || "The other device reported an error.");
    void teardown();
    return;
  }
  if (live.role === "send" && data.t === "accept") {
    live.peerId = from;
    live.accept?.resolve();
    return;
  }
  if (live.role === "receive" && data.t === "manifest") {
    live.peerId = from;
    startIncoming(from, data.files);
    return;
  }
  if (live.role === "receive" && data.t === "done") {
    finishIncoming();
  }
}

function onBinary(_from: string, chunk: ArrayBuffer) {
  if (!live || live.closed || live.role !== "receive" || !live.incoming) return;
  consumeChunk(chunk);
}

function startIncoming(
  from: string,
  files: { id: string; name: string; size: number; mime: string }[],
) {
  if (!live || live.incoming) return;
  const list: FileProgress[] = files.map((f) => ({
    id: f.id,
    name: f.name,
    size: f.size,
    mime: f.mime || "application/octet-stream",
    bytes: 0,
    status: "queued",
  }));
  live.incoming = { list, index: 0, receivedInFile: 0, parts: [], finished: false };
  const totalBytes = list.reduce((sum, f) => sum + f.size, 0);
  patchShare({
    phase: "transferring",
    statusText: "Receiving files",
    files: list,
    totalBytes,
    transferredBytes: 0,
  });
  live.p2p.send({ t: "accept" } satisfies ControlMessage, from);
  settleEmptyFiles();
  if (live.incoming && live.incoming.index >= list.length) finishIncoming();
}

function settleEmptyFiles() {
  const incoming = live?.incoming;
  if (!incoming) return;
  while (incoming.index < incoming.list.length && incoming.list[incoming.index]!.size === 0) {
    finalizeCurrentFile();
  }
}

function consumeChunk(chunk: ArrayBuffer) {
  const incoming = live?.incoming;
  if (!incoming || incoming.finished) return;
  let offset = 0;
  while (offset < chunk.byteLength && incoming.index < incoming.list.length) {
    const current = incoming.list[incoming.index]!;
    if (current.size === 0) {
      finalizeCurrentFile();
      continue;
    }
    current.status = "active";
    const need = current.size - incoming.receivedInFile;
    const take = Math.min(need, chunk.byteLength - offset);
    incoming.parts.push(chunk.slice(offset, offset + take));
    incoming.receivedInFile += take;
    current.bytes = incoming.receivedInFile;
    offset += take;
    const transferred = incoming.list.reduce((sum, f) => sum + f.bytes, 0);
    noteSpeed(transferred);
    patchShare({ files: incoming.list.map((f) => ({ ...f })) });
    if (incoming.receivedInFile >= current.size) finalizeCurrentFile();
  }
}

function finalizeCurrentFile() {
  const incoming = live?.incoming;
  if (!incoming) return;
  const current = incoming.list[incoming.index];
  if (!current) return;
  const blob = new Blob(incoming.parts, { type: current.mime });
  const url = URL.createObjectURL(blob);
  current.bytes = current.size;
  current.status = "done";
  const received: ReceivedFile = {
    id: current.id,
    name: current.name,
    mime: current.mime,
    size: current.size,
    url,
  };
  patchShare({
    files: incoming.list.map((f) => ({ ...f })),
    received: [...useShareStore.getState().received, received],
  });
  tryDownload(received);
  incoming.parts = [];
  incoming.receivedInFile = 0;
  incoming.index += 1;
  if (incoming.index >= incoming.list.length) finishIncoming();
}

function tryDownload(file: ReceivedFile) {
  try {
    const a = document.createElement("a");
    a.href = file.url;
    a.download = file.name;
    a.rel = "noopener";
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    a.remove();
  } catch {
    // User can tap the file in the success screen.
  }
}

function finishIncoming() {
  const incoming = live?.incoming;
  if (!incoming || incoming.finished) return;
  settleEmptyFiles();
  if (incoming.index < incoming.list.length) return;
  incoming.finished = true;
  const allDone = incoming.list.every((f) => f.status === "done");
  if (!allDone) {
    fail("The transfer ended before every file arrived.");
    void teardown();
    return;
  }
  patchShare({
    phase: "complete",
    statusText: "Files received",
    transferredBytes: incoming.list.reduce((sum, f) => sum + f.size, 0),
    speedBps: 0,
    etaSec: 0,
  });
  void teardown(false);
}

async function sendLoop(peerId: string) {
  if (!live) return;
  patchShare({ phase: "transferring", statusText: "Sending files" });
  const files = live.files;
  const metas = live.metas;
  let transferred = 0;
  for (let i = 0; i < files.length; i += 1) {
    if (!live || live.closed) return;
    const file = files[i]!;
    const meta = metas[i]!;
    meta.status = "active";
    patchShare({ files: metas.map((f) => ({ ...f })) });
    let offset = 0;
    while (offset < file.size) {
      if (!live || live.closed) return;
      const end = Math.min(offset + CHUNK, file.size);
      const buf = await file.slice(offset, end).arrayBuffer();
      await live.p2p.sendBinary(buf, peerId);
      offset = end;
      meta.bytes = offset;
      transferred += buf.byteLength;
      noteSpeed(transferred);
      patchShare({ files: metas.map((f) => ({ ...f })) });
    }
    meta.status = "done";
    meta.bytes = file.size;
    patchShare({ files: metas.map((f) => ({ ...f })) });
  }
  if (!live || live.closed) return;
  live.p2p.send({ t: "done" } satisfies ControlMessage, peerId);
  patchShare({
    phase: "complete",
    statusText: "Sent",
    transferredBytes: live.metas.reduce((sum, f) => sum + f.size, 0),
    speedBps: 0,
    etaSec: 0,
  });
  void teardown(false);
}

function waitForPeer(timeoutMs: number): Promise<PeerInfo> {
  return new Promise((resolve, reject) => {
    if (!live) {
      reject(new Error("No session"));
      return;
    }
    const existing = live.p2p
      .peerList()
      .find((p) => p.filesReady && p.connectionState === "connected");
    if (existing) {
      resolve(existing);
      return;
    }
    const original = live;
    let settled = false;
    let poll = 0;
    let timer = 0;
    const finish = (fn: () => void) => {
      if (settled) return;
      settled = true;
      window.clearInterval(poll);
      window.clearTimeout(timer);
      fn();
    };
    poll = window.setInterval(() => {
      if (!live || live !== original || live.closed) {
        finish(() => reject(new Error("Session closed")));
        return;
      }
      applyPeer(live.p2p.peerList());
      const ready = live.p2p
        .peerList()
        .find((p) => p.filesReady && p.connectionState === "connected");
      if (ready) finish(() => resolve(ready));
    }, 200);
    timer = window.setTimeout(() => {
      finish(() => reject(new Error("Timed out waiting for the other device.")));
    }, timeoutMs);
  });
}

function openRoom(opts: { room: string; selfId: string; name: string; role: "send" | "receive"; files: File[] }) {
  const acceptWait: { resolve: () => void; promise: Promise<void> } = {
    resolve: () => {},
    promise: Promise.resolve(),
  };
  acceptWait.promise = new Promise<void>((resolve) => {
    acceptWait.resolve = resolve;
  });

  const p2p = new P2PRoom({
    room: opts.room,
    selfId: opts.selfId,
    name: opts.name,
    onPeersChanged: applyPeer,
    onMessage: (from, data) => onMessage(from, data),
    onBinary,
    onFilesReady: () => {
      applyPeer(p2p.peerList());
    },
  });

  live = {
    p2p,
    role: opts.role,
    closed: false,
    peerId: null,
    files: opts.files,
    metas: opts.files.map((file, i) => ({
      id: `f${i}_${file.name}`.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 80),
      name: file.name,
      size: file.size,
      mime: file.type || "application/octet-stream",
      bytes: 0,
      status: "queued",
    })),
    accept: acceptWait,
    incoming: null,
    samples: [],
  };

  return p2p.join();
}

async function teardown(reset = true) {
  const session = live;
  if (!session) return;
  session.closed = true;
  live = null;
  try {
    session.p2p.close();
  } catch {
    // ignore
  }
  if (reset) {
    // Keep share store as-is so the UI can show success/error; caller resets.
  }
}

export async function beginSend(files: File[]): Promise<string> {
  await teardown();
  const room = createRoomId();
  const selfId = createPeerId("s");
  const metas: FileProgress[] = files.map((file, i) => ({
    id: `f${i}_${file.name}`.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 80),
    name: file.name,
    size: file.size,
    mime: file.type || "application/octet-stream",
    bytes: 0,
    status: "queued",
  }));
  patchShare({
    role: "send",
    phase: "waiting",
    roomId: room,
    statusText: "Waiting for the other device",
    files: metas,
    totalBytes: files.reduce((sum, f) => sum + f.size, 0),
    transferredBytes: 0,
    speedBps: 0,
    etaSec: null,
    error: null,
    peerConnected: false,
    linkType: null,
    outgoing: files,
    received: [],
  });
  await openRoom({ room, selfId, name: "Sender", role: "send", files });
  void runSend().catch((err) => {
    const message = err instanceof Error ? err.message : "Could not send files.";
    fail(message);
    void teardown();
  });
  return room;
}

async function runSend() {
  const session = live;
  if (!session) return;
  const peer = await waitForPeer(WAIT_PEER_MS);
  if (!live || live.closed) return;
  live.peerId = peer.id;
  patchShare({
    phase: "connecting",
    statusText: "Direct link established",
    peerConnected: true,
    linkType: peer.candidateType,
  });
  live.p2p.send(
    {
      t: "manifest",
      files: live.metas.map(({ id, name, size, mime }) => ({ id, name, size, mime })),
    } satisfies ControlMessage,
    peer.id,
  );
  const accepted = await Promise.race([
    live.accept?.promise ?? Promise.resolve(),
    new Promise<void>((resolve) => window.setTimeout(resolve, 8000)),
  ]);
  void accepted;
  if (!live || live.closed) return;
  await sendLoop(peer.id);
}

export async function beginReceive(roomId: string) {
  await teardown();
  const selfId = createPeerId("r");
  patchShare({
    role: "receive",
    phase: "connecting",
    roomId,
    statusText: "Connecting over a direct link",
    files: [],
    totalBytes: 0,
    transferredBytes: 0,
    error: null,
    peerConnected: false,
    linkType: null,
    outgoing: [],
    received: [],
  });
  await openRoom({ room: roomId, selfId, name: "Receiver", role: "receive", files: [] });
  try {
    await waitForPeer(WAIT_PEER_MS);
    if (!live || live.closed) return;
    patchShare({
      phase: "connecting",
      statusText: "Connected — waiting for files",
      peerConnected: true,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Could not connect.";
    fail(message);
    void teardown();
  }
}

export async function cancelActive(reason = "Cancelled") {
  const session = live;
  if (session && !session.closed && session.peerId) {
    try {
      session.p2p.send({ t: "cancel" } satisfies ControlMessage, session.peerId);
    } catch {
      // ignore
    }
  }
  const had = Boolean(session);
  await teardown();
  if (!had) return;
  if (useShareStore.getState().phase === "complete") return;
  patchShare({
    phase: "failed",
    error: reason,
    statusText: reason,
  });
}

export async function stopAndReset() {
  await teardown();
  resetShareState();
}

export function currentRoomId(): string | null {
  return live && !live.closed ? useShareStore.getState().roomId : useShareStore.getState().roomId;
}
