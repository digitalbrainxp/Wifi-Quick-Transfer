import { Check, RotateCcw, TriangleAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FileList } from "@/components/file-list";
import type { FileProgress, ReceivedFile } from "@/lib/share/store";

export function SuccessCard({
  title,
  body,
  files,
  received,
  onHome,
}: {
  title: string;
  body: string;
  files: FileProgress[];
  received: ReceivedFile[];
  onHome: () => void;
}) {
  return (
    <div className="stagger-in flex flex-1 flex-col gap-5 pt-6">
      <div className="flex flex-col items-center text-center">
        <span className="flex size-16 items-center justify-center rounded-full bg-success/12 text-success">
          <Check className="size-8" strokeWidth={2} />
        </span>
        <h2 className="mt-4 text-2xl font-semibold tracking-tight">{title}</h2>
        <p className="mt-2 max-w-[34ch] text-sm text-muted">{body}</p>
      </div>
      {received.length > 0 ? (
        <ul className="flex flex-col gap-2">
          {received.map((file) => (
            <li key={file.id}>
              <a
                href={file.url}
                download={file.name}
                className="flex items-center justify-between rounded-lg border border-border bg-surface px-4 py-3 text-sm"
              >
                <span className="truncate font-medium">{file.name}</span>
                <span className="shrink-0 text-xs text-muted">Save</span>
              </a>
            </li>
          ))}
        </ul>
      ) : (
        <FileList files={files} showProgress />
      )}
      <Button variant="ink" size="lg" block onClick={onHome}>
        Done
      </Button>
    </div>
  );
}

export function ErrorCard({
  message,
  onRetry,
  onHome,
}: {
  message: string;
  onRetry: () => void;
  onHome: () => void;
}) {
  return (
    <div className="stagger-in flex flex-1 flex-col items-center justify-center gap-5 text-center">
      <span className="flex size-16 items-center justify-center rounded-full bg-danger/12 text-danger">
        <TriangleAlert className="size-8" strokeWidth={1.75} />
      </span>
      <div>
        <h2 className="text-2xl font-semibold tracking-tight">Couldn’t finish</h2>
        <p className="mt-2 max-w-[34ch] text-sm text-muted">{message}</p>
      </div>
      <div className="flex w-full flex-col gap-2">
        <Button variant="ink" size="lg" block onClick={onRetry}>
          <RotateCcw className="size-4" strokeWidth={1.75} />
          Try again
        </Button>
        <Button variant="ghost" size="md" block onClick={onHome}>
          Home
        </Button>
      </div>
    </div>
  );
}
