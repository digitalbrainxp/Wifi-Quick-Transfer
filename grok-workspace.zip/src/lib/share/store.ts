import { create } from "zustand";

export type ShareRole = "send" | "receive";
export type SharePhase =
  | "idle"
  | "picking"
  | "waiting"
  | "connecting"
  | "transferring"
  | "complete"
  | "failed";

export type FileStatus = "queued" | "active" | "done" | "error";

export interface FileProgress {
  id: string;
  name: string;
  size: number;
  mime: string;
  bytes: number;
  status: FileStatus;
}

export interface ReceivedFile {
  id: string;
  name: string;
  mime: string;
  size: number;
  url: string;
}

export interface ShareState {
  role: ShareRole | null;
  phase: SharePhase;
  roomId: string | null;
  statusText: string;
  files: FileProgress[];
  totalBytes: number;
  transferredBytes: number;
  speedBps: number;
  etaSec: number | null;
  error: string | null;
  peerConnected: boolean;
  linkType: string | null;
  rttMs: number | null;
  received: ReceivedFile[];
  outgoing: File[];
}

const initial: Omit<ShareState, "outgoing"> & { outgoing: File[] } = {
  role: null,
  phase: "idle",
  roomId: null,
  statusText: "",
  files: [],
  totalBytes: 0,
  transferredBytes: 0,
  speedBps: 0,
  etaSec: null,
  error: null,
  peerConnected: false,
  linkType: null,
  rttMs: null,
  received: [],
  outgoing: [],
};

export const useShareStore = create<ShareState>(() => ({ ...initial, outgoing: [] }));

export function patchShare(partial: Partial<ShareState>) {
  useShareStore.setState(partial);
}

export function resetShareState() {
  const prev = useShareStore.getState().received;
  for (const file of prev) URL.revokeObjectURL(file.url);
  useShareStore.setState({ ...initial, outgoing: [] });
}
