import { useEffect } from "react";
import { applyTheme, readTheme } from "@/lib/share/theme";

export function ThemeBoot() {
  useEffect(() => {
    applyTheme(readTheme());
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => applyTheme(readTheme());
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);
  return null;
}