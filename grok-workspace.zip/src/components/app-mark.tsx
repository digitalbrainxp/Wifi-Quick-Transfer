import { cn } from "@/lib/utils";

export function AppMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("size-8", className)}
      fill="none"
      aria-hidden="true"
    >
      <rect x="1" y="1" width="30" height="30" rx="9" className="fill-fg" />
      <path
        d="M10 18.5c2.4-2.4 9.6-2.4 12 0M12.2 15.2c1.6-1.5 6-1.5 7.6 0M15.2 12.2c.8-.7 1.8-.7 2.6 0"
        className="stroke-bg"
        strokeWidth="1.7"
        strokeLinecap="round"
      />
      <circle cx="16" cy="21.4" r="1.35" className="fill-bg" />
    </svg>
  );
}
