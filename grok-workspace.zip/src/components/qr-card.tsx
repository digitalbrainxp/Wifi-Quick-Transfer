import { useEffect, useState } from "react";
import { displayCode } from "@/lib/share/ids";
import { makeQrDataUrl, pairUrl } from "@/lib/share/qr";

export function QrCard({ roomId }: { roomId: string }) {
  const [src, setSrc] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    void makeQrDataUrl(pairUrl(roomId)).then((url) => {
      if (!cancelled) setSrc(url);
    });
    return () => {
      cancelled = true;
    };
  }, [roomId]);

  const code = displayCode(roomId);

  return (
    <div className="relative mx-auto w-full max-w-[280px]">
      <span className="pulse-ring pointer-events-none absolute inset-[-10%] rounded-[36px] border border-accent/30" />
      <span
        className="pulse-ring pointer-events-none absolute inset-[-10%] rounded-[36px] border border-accent/20"
        style={{ animationDelay: "0.7s" }}
      />
      <div
        className="relative overflow-hidden rounded-xl bg-surface-2 p-5 ring-1 ring-border"
        style={{ boxShadow: "var(--shadow)" }}
      >
        <div className="aspect-square overflow-hidden rounded-md bg-qr">
          {src ? (
            <img src={src} alt="Pairing QR code" className="size-full" />
          ) : (
            <div className="size-full animate-pulse bg-fg/5" />
          )}
        </div>
        <p className="mt-4 text-center text-[11px] font-medium uppercase tracking-[0.2em] text-subtle">
          Pairing code
        </p>
        <p className="mt-1 text-center font-mono text-lg font-medium tracking-[0.28em] text-fg tabular-nums">
          {code}
        </p>
      </div>
    </div>
  );
}
