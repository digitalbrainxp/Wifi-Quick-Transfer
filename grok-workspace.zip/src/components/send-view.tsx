import { useNavigate } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { useCallback, useRef } from "react";
import { AppShell, ScreenHeader } from "@/components/app-shell";
import { FileList } from "@/components/file-list";
import { ErrorCard, SuccessCard } from "@/components/outcome";
import { ProgressPanel } from "@/components/progress-panel";
import { QrCard } from "@/components/qr-card";
import { Button } from "@/components/ui/button";
import { beginSend, cancelActive, stopAndReset } from "@/lib/share/controller";
import { formatBytes } from "@/lib/share/format";
import { useShareStore, type FileProgress } from "@/lib/share/store";

function asProgress(files: File[]): FileProgress[] {
  return files.map((file, i) => ({
    id: `local-${i}-${file.name}`,
    name: file.name,
    size: file.size,
    mime: file.type || "application/octet-stream",
    bytes: 0,
    status: "queued",
  }));
}

export function SendView() {
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);
  const state = useShareStore();

  const goHome = useCallback(async () => {
    await stopAndReset();
    void navigate({ to: "/" });
  }, [navigate]);

  const onPick = (list: globalThis.FileList | null) => {
    if (!list || list.length === 0) return;
    const files = Array.from(list);
    useShareStore.setState({
      role: "send",
      phase: "picking",
      outgoing: files,
      files: asProgress(files),
      totalBytes: files.reduce((sum, f) => sum + f.size, 0),
      error: null,
    });
  };

  const start = async () => {
    const files = useShareStore.getState().outgoing;
    if (files.length === 0) return;
    await beginSend(files);
  };

  const retry = async () => {
    const files = useShareStore.getState().outgoing;
    if (files.length === 0) {
      useShareStore.setState({ phase: "picking", error: null });
      return;
    }
    await beginSend(files);
  };

  const phase = state.phase === "idle" ? "picking" : state.phase;

  return (
    <AppShell>
      <ScreenHeader
        title={
          phase === "waiting"
            ? "Show this code"
            : phase === "complete"
              ? "Sent"
              : phase === "failed"
                ? "Send failed"
                : phase === "transferring" || phase === "connecting"
                  ? "Sending"
                  : "Send"
        }
        subtitle={
          phase === "picking"
            ? "Photos, videos, or any file. They never leave the two devices."
            : phase === "waiting"
              ? "Open Receive on the other device and scan this QR."
              : undefined
        }
        onBack={
          phase === "complete"
            ? undefined
            : () => {
                if (phase !== "picking") void cancelActive("Cancelled");
                void goHome();
              }
        }
      />

      {phase === "picking" ? (
        <div className="stagger-in mt-6 flex flex-1 flex-col gap-4">
          <input
            ref={inputRef}
            type="file"
            multiple
            className="sr-only"
            onChange={(e) => onPick(e.target.files)}
          />
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            className="flex min-h-40 flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-border bg-surface px-6 text-center transition-transform duration-150 active:scale-[0.98]"
          >
            <span className="flex size-12 items-center justify-center rounded-lg bg-fg/5">
              <Plus className="size-6" strokeWidth={1.75} />
            </span>
            <span>
              <span className="block text-base font-medium">Choose files</span>
              <span className="mt-1 block text-sm text-muted">One or many — photos, videos, documents</span>
            </span>
          </button>

          {state.outgoing.length > 0 ? (
            <>
              <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">
                {state.outgoing.length} selected · {formatBytes(state.totalBytes)}
              </p>
              <FileList files={state.files} />
              <div className="mt-auto flex flex-col gap-2 pt-4">
                <Button variant="ink" size="lg" block onClick={() => void start()}>
                  Continue
                </Button>
                <Button variant="ghost" size="md" block onClick={() => inputRef.current?.click()}>
                  Add more
                </Button>
              </div>
            </>
          ) : null}
        </div>
      ) : null}

      {phase === "waiting" && state.roomId ? (
        <div className="stagger-in mt-8 flex flex-1 flex-col gap-6">
          <QrCard roomId={state.roomId} />
          <p className="text-center text-sm text-muted">
            Waiting for the other device to scan.
            <span className="mt-1 block text-xs text-subtle">
              Keep this screen open. The file data stays on-device until they connect.
            </span>
          </p>
          {state.files.length > 0 ? <FileList files={state.files} /> : null}
          <Button variant="ghost" size="md" block onClick={() => void goHome()}>
            Cancel
          </Button>
        </div>
      ) : null}

      {phase === "connecting" || phase === "transferring" ? (
        <div className="mt-6 flex flex-1 flex-col gap-5">
          <ProgressPanel
            phase={phase}
            files={state.files}
            transferredBytes={state.transferredBytes}
            totalBytes={state.totalBytes}
            speedBps={state.speedBps}
            etaSec={state.etaSec}
            peerConnected={state.peerConnected}
            linkType={state.linkType}
            rttMs={state.rttMs}
            statusText={state.statusText}
          />
          <Button variant="danger" size="md" block onClick={() => void cancelActive("Transfer cancelled")}>
            Cancel transfer
          </Button>
        </div>
      ) : null}

      {phase === "complete" ? (
        <SuccessCard
          title="On the other device"
          body="Every selected file was sent over the direct link."
          files={state.files}
          received={[]}
          onHome={() => void goHome()}
        />
      ) : null}

      {phase === "failed" ? (
        <ErrorCard
          message={state.error ?? "The connection was interrupted."}
          onRetry={() => void retry()}
          onHome={() => void goHome()}
        />
      ) : null}
    </AppShell>
  );
}
